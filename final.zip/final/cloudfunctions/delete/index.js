const cloud = require('wx-server-sdk')
cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
})
const db = cloud.database()
exports.main = async (event, context) => {
  let {
  str
  } = event

 
  try {
    const _=db.command
    return await db.collection('hello').where({
     str:_.exists(true)
    }).remove()
  } catch (e) {
    console.error(e)
  }
}