var that
const app = getApp()
const ad = wx.createInnerAudioContext();

Page({

  data: {
    motto: '空的你叫我怎么读啊',
    tempFilePaths: null,
    i: 0,
    token: '',
    spd: 5,//语速
    vol: 5,//音量
    pit: 5,//音调
    per: 0,//音色
    body_list: [
      {
        'id': '0',
        'name': '普通女声',
        'checked': true,
      },
      {
        'id': '1',
        'name': '普通男生',
        'checked': false,
      },
      {
        'id': '3',
        'name': '度逍遥',
        'checked': false,
      },
      {
        'id': '4',
        'name': '度丫丫',
        'checked': false,
      },
    ],
  },

  onLoad: function () {
    that = this;
    that.getToken();
    

  },
  getToken() 
  //获取token
  {
    var token = wx.getStorageSync('token');
    var token_expire = wx.getStorageSync('token_expire');
    if (!token || token_expire <= new Date().getTime()) {
      let api_key = 'EsVw8XUyLnIb6P20MOYGqraC';
      let secret_key = 'BakA5LiaWvBr9Qy6VFAnz35Ycce6wzr5';
      var url = "https://openapi.baidu.com/oauth/2.0/token?grant_type=client_credentials&client_id=" + api_key + "&client_secret=" + secret_key;//调用百度语音合成的api
      wx.showLoading({
        title: '加载中...',
      })
      wx.request({
        url: url,
        success: e => {
          token = e.data.access_token;
          token_expire = e.data.expires_in * 1000 + new Date().getTime();
          wx.setStorageSync('token', token);
          wx.setStorageSync('token_expire', token_expire);
          that.setData({
            token: token
          })
        },
        fail() {
          ws.showToast({
            'title': '哎呀,你断网了吧',
          });
        },
        complete() {
          wx.hideLoading();
        }
      })
    } else {
      that.setData({
        token: token
      })
    }
  },
  changeSpd(e) {
    that.setData({
      spd: e.detail.value
    })
  },
  changeVol(e) {
    that.setData({
      vol: e.detail.value
    })
  },
  changePit(e) {
    that.setData({
      pit: e.detail.value
    })
  },
  changeBody(e) {
    console.log(e);
    that.setData({
      per: e.detail.value
    })
  },



  //确定图片来源，从相册中选择或者是拍照
  chooseImage: function () {
    wx.showActionSheet({
      itemList: ['从相册中选择', '拍照'],
      itemColor: "#CED63A",
      success: (res) => {
        if (res.cancel) {
          return;
        }
        if (res.tapIndex == 0) {
          this.chooseWxImage('album')
        } else if (res.tapIndex == 1) {
          this.chooseWxImage('camera')
        }
      }
    })

  },

  //选择图片
  chooseWxImage: function (type) {
    wx.chooseImage({
      sizeType: ['original', 'compressed'],
      sourceType: [type],
      success: (res) => {
        this.setData({
          tempFilePaths: res.tempFilePaths,
        })
      }
    })
  },

  //上传图片至服务器并接受返回的结果
  identifyImage: function () {
    var that = this
    if (!this.data.tempFilePaths) {
      console.error("no selected image")
      return;
    }
    /**
     * 调用微信上传文件接口, 此处向我们的本地服务器发送请求, 故运行此代码时要确保本地服务已经启动
     */
    wx.uploadFile({
      url: 'https://wclnb.hfzhang.wang', //云服务器的地址
      filePath: this.data.tempFilePaths[0],
      name: 'image',
      header: { "Content-Type": "multipart/form-data" },
      success: (res) => {
        console.log(res)
        console.log(data)
        var data = JSON.parse(res.data) //把返回结果解析成json格式

        //识别成功，拼接识别结果并显示
        var list = data.data.items;
        var str = list.map(j => j.itemstring).join(" ");

        wx.cloud.init
          ({
            traceUser: true
          })
        const db = wx.cloud.database()
        db.collection('hello').add//将代码上传到数据库
          ({
            data:
            {
              str,

            }
          })
        wx.showToast({
          title: '识别成功',
        })


      },
      fail: (err) => {
        console.error(err)
      }
    })
  },
  onShareAppMessage: function (res) {
    if (res.from === 'button') {
      // 来自页面内转发按钮
      console.log(res.target)
    }
    return {
      title: '听书',
      path: '/page/user?id=123'
    }
  },
  saving: function () {
    var i = this.data.i
    var that = this
    wx.cloud.init
      ({
        traceUser: true
      })
    const bd = wx.cloud.database();
    bd.collection('hello').where({
      _openid: this.data.openid
    }).get//读取数据库里的数据
      ({
        success: res => {
          console.log(res.data[i])
          wx.showToast({
            title: '提取成功',
          })
          that.setData
            ({
              motto: res.data[i].str
            })
          i++
          that.setData({ i: i })

        }
      })

  },
  delete:function()
  {
    var that = this
    wx.cloud.init
      ({
        traceUser: true
      })
    
    wx.cloud.callFunction({
      // 云函数名称
      name: 'delete',
      // 传给云函数的参数
     success:function()
     {
       wx.showToast({
         title:'初始化成功',
       })
     }
    })
  },
  submit(e) {
    that = this
    let data = e.detail.value;
    data['tok'] = that.data.token;
    data['cuid'] = 'txx_xcx';
    data['lan'] = 'zh';
    data['ctp'] = 1;
    data['tex'] = that.data.motto;
    console.log(e)
    let arr = [];
    for (var x in data) {
      arr.push(x + '=' + data[x]);
    }
    let str = arr.join('&');
    ad.src = encodeURI('https://tsn.baidu.com/text2audio?' + str);
    ad.play();//播放
  },
})